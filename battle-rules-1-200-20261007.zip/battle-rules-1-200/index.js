module.exports = { pets: require('./data/pets.json'), skills: require('./data/skills.json'), traits: require('./data/traits.json'), manifest: require('./manifest.json') };
