# 阅读索引

数字编号采用本项目图鉴数据ID。实际源码入口见 `rule-index.json`；每条规则对应多个执行阶段。

## 技能

| 图鉴ID | 技能 | 引擎内部ID | 类别 |
| --- | --- | --- | --- |
| 1 | 闪光冲击 | skill_59 | physical |
| 2 | 光刃 | skill_60 | physical |
| 3 | 光之矛 | skill_61 | physical |
| 4 | 透射 | skill_62 | physical |
| 5 | 折线冲击 | skill_63 | physical |
| 6 | 放晴 | skill_status_1 | status |
| 7 | 漫反射 | skill_status_2 | status |
| 8 | 镜像反射 | skill_defense_1 | defense |
| 9 | 虹光冲击 | skill_1 | magical |
| 10 | 脉冲光线 | skill_2 | magical |
| 11 | 折射 | skill_refract | magical |
| 12 | 闪光 | skill_3 | magical |
| 13 | 过曝 | skill_c_103 | magical |
| 14 | 光球 | skill_4 | magical |
| 15 | 天光 | skill_c_104 | magical |
| 16 | 冰雹 | skill_c_1 | physical |
| 17 | 冰锥 | skill_64 | physical |
| 18 | 滚雪球 | skill_c_2 | physical |
| 19 | 冰爪 | skill_65 | physical |
| 20 | 暴风雪 | skill_c_3 | physical |
| 21 | 冰晶坠 | skill_c_4 | physical |
| 22 | 丢冰块 | skill_c_5 | physical |
| 23 | 霜降 | skill_status_3 | status |
| 24 | 霜天 | skill_status_4 | status |
| 25 | 瞬间零度 | skill_status_5 | status |
| 26 | 冰捆缚 | skill_status_6 | status |
| 27 | 雪球 | skill_status_7 | status |
| 28 | 速冻 | skill_status_8 | status |
| 29 | 霜冻 | skill_status_9 | status |
| 30 | 冰点 | skill_status_10 | status |
| 31 | 冬至 | skill_status_11 | status |
| 32 | 雾气环绕 | skill_status_12 | status |
| 33 | 雪替身 | skill_defense_2 | defense |
| 34 | 冰天雪地 | skill_defense_3 | defense |
| 35 | 冰蛋壳 | skill_defense_4 | defense |
| 36 | 冰墙 | skill_defense_5 | defense |
| 37 | 冰锋横扫 | skill_c_105 | magical |
| 38 | 极寒领域 | skill_c_106 | magical |
| 39 | 风吹雪 | skill_c_107 | magical |
| 40 | 碎冰冰 | skill_c_108 | magical |
| 41 | 打雪仗 | skill_5 | magical |
| 42 | 冷风 | skill_6 | magical |
| 43 | 寒风吹 | skill_c_109 | magical |
| 44 | 冰冻光线 | skill_c_110 | magical |
| 45 | 岩脉崩毁 | skill_c_6 | physical |
| 46 | 抛石 | skill_c_7 | physical |
| 47 | 岩土暴击 | skill_c_8 | physical |
| 48 | 地震 | skill_66 | physical |
| 49 | 石锁 | skill_c_9 | physical |
| 50 | 落石 | skill_67 | physical |
| 51 | 鸣沙陷阱 | skill_c_10 | physical |
| 52 | 扬沙 | skill_68 | physical |
| 53 | 跺地 | skill_69 | physical |
| 54 | 震击 | skill_c_11 | physical |
| 55 | 砂石冲撞 | skill_c_12 | physical |
| 56 | 地陷 | skill_c_13 | physical |
| 57 | 裂石 | skill_c_14 | physical |
| 58 | 地刺 | skill_c_15 | physical |
| 59 | 石肤术 | skill_status_13 | status |
| 60 | 蓄势待发 | skill_status_14 | status |
| 61 | 钧势 | skill_status_15 | status |
| 62 | 泥浆铠甲 | skill_status_16 | status |
| 63 | 沙涌 | skill_status_17 | status |
| 64 | 流沙 | skill_status_18 | status |
| 65 | 遁地 | skill_defense_6 | defense |
| 66 | 壁垒 | skill_defense_7 | defense |
| 67 | 硬化 | skill_defense_8 | defense |
| 68 | 刺盾 | skill_defense_9 | defense |
| 69 | 不动如山 | skill_defense_10 | defense |
| 70 | 淤泥表皮 | skill_defense_11 | defense |
| 71 | 陨石 | skill_7 | magical |
| 72 | 泥浆 | skill_8 | magical |
| 73 | 泥巴喷射 | skill_9 | magical |
| 74 | 热砂 | skill_10 | magical |
| 75 | 双星 | skill_70 | physical |
| 76 | 偷师 | skill_c_16 | physical |
| 77 | 粒子对撞 | skill_71 | physical |
| 78 | 星云漩涡 | skill_72 | physical |
| 79 | 空间压迫 | skill_c_17 | physical |
| 80 | 念力膨胀 | skill_73 | physical |
| 81 | 超维投射 | skill_status_19 | status |
| 82 | 二律背反 | skill_status_20 | status |
| 83 | 星轨裂变 | skill_status_21 | status |
| 84 | 心灵洞悉 | skill_status_22 | status |
| 85 | 星链 | skill_status_23 | status |
| 86 | 超新星馈赠 | skill_status_24 | status |
| 87 | 冥想 | skill_defense_12 | defense |
| 88 | 大爆炸 | skill_11 | magical |
| 89 | 四维降解 | skill_c_111 | magical |
| 90 | 多维击打 | skill_c_112 | magical |
| 91 | 针状物 | skill_12 | magical |
| 92 | 错乱 | skill_c_113 | magical |
| 93 | 坍缩 | skill_c_114 | magical |
| 94 | 坟场搏击 | skill_c_18 | physical |
| 95 | 诡刺 | skill_74 | physical |
| 96 | 幻象 | skill_75 | physical |
| 97 | 惊吓盒子 | skill_c_19 | physical |
| 98 | 恶作剧 | skill_status_25 | status |
| 99 | 嘲弄 | skill_status_26 | status |
| 100 | 勾魂 | skill_status_27 | status |
| 101 | 降灵 | skill_status_28 | status |
| 102 | 报复 | skill_defense_13 | defense |
| 103 | 虚化 | skill_defense_14 | defense |
| 104 | 灵媒 | skill_13 | magical |
| 105 | 幽灵爆发 | skill_14 | magical |
| 106 | 午夜噪音 | skill_15 | magical |
| 107 | 灵光 | skill_c_115 | magical |
| 108 | 鬼火 | skill_c_116 | magical |
| 109 | 背袭 | skill_c_117 | magical |
| 110 | 恐吓 | skill_16 | magical |
| 111 | 跌落 | skill_c_20 | physical |
| 112 | 极限撕裂 | skill_c_21 | physical |
| 113 | 彼岸之手 | skill_c_22 | physical |
| 114 | 灾厄 | skill_c_23 | physical |
| 115 | 魔爪 | skill_c_24 | physical |
| 116 | 撕咬 | skill_c_25 | physical |
| 117 | 趁火打劫 | skill_c_26 | physical |
| 118 | 迫害 | skill_76 | physical |
| 119 | 恶能量 | skill_77 | physical |
| 120 | 蝙蝠 | skill_c_27 | physical |
| 121 | 暗突袭 | skill_c_28 | physical |
| 122 | 诋毁 | skill_78 | physical |
| 123 | 撕裂 | skill_c_29 | physical |
| 124 | 伪造账单 | skill_status_29 | status |
| 125 | 恶念交换 | skill_status_30 | status |
| 126 | 隐藏条款 | skill_status_31 | status |
| 127 | 欺诈契约 | skill_status_32 | status |
| 128 | 力量吞噬 | skill_status_33 | status |
| 129 | 恶意逃离 | skill_status_34 | status |
| 130 | 贪婪 | skill_status_35 | status |
| 131 | 暗箱操作 | skill_status_36 | status |
| 132 | 虚假破产 | skill_defense_15 | defense |
| 133 | 等价交换 | skill_defense_16 | defense |
| 134 | 栽赃 | skill_17 | magical |
| 135 | 黑手 | skill_18 | magical |
| 136 | 掠夺 | skill_19 | magical |
| 137 | 牵连 | skill_c_118 | magical |
| 138 | 以重制重 | skill_c_30 | physical |
| 139 | 吨位压制 | skill_c_31 | physical |
| 140 | 逆袭 | skill_c_32 | physical |
| 141 | 飞踢 | skill_79 | physical |
| 142 | 重击 | skill_c_33 | physical |
| 143 | 践踏 | skill_80 | physical |
| 144 | 冲撞 | skill_c_34 | physical |
| 145 | 吞噬 | skill_c_35 | physical |
| 146 | 压扁 | skill_81 | physical |
| 147 | 后发制人 | skill_c_36 | physical |
| 148 | 连续爪击 | skill_c_37 | physical |
| 149 | 旋转突击 | skill_82 | physical |
| 150 | 抓挠 | skill_c_38 | physical |
| 151 | 乘胜追击 | skill_c_39 | physical |
| 152 | 落星 | skill_83 | physical |
| 153 | 先发制人 | skill_c_40 | physical |
| 154 | 天旋地转 | skill_c_41 | physical |
| 155 | 见招拆招 | skill_c_42 | physical |
| 156 | 猛烈撞击 | skill_84 | physical |
| 157 | 穿膛 | skill_c_43 | physical |
| 158 | 能量刃 | skill_c_44 | physical |
| 159 | 垂死反击 | skill_c_45 | physical |
| 160 | 当头棒喝 | skill_c_46 | physical |
| 161 | 气势一击 | skill_c_47 | physical |
| 162 | 偷袭 | skill_c_48 | physical |
| 163 | 扫尾 | skill_85 | physical |
| 164 | 迫近攻击 | skill_c_49 | physical |
| 165 | 锐利眼神 | skill_status_37 | status |
| 166 | 取念 | skill_status_38 | status |
| 167 | 精神扰乱 | skill_status_39 | status |
| 168 | 棘刺 | skill_status_40 | status |
| 169 | 复写 | skill_status_41 | status |
| 170 | 主场优势 | skill_status_42 | status |
| 171 | 鼓劲 | skill_status_43 | status |
| 172 | 摇篮曲 | skill_status_44 | status |
| 173 | 操控 | skill_status_45 | status |
| 174 | 耀眼 | skill_status_46 | status |
| 175 | 魔法增效 | skill_status_47 | status |
| 176 | 晒太阳 | skill_status_48 | status |
| 177 | 热身运动 | skill_status_49 | status |
| 178 | 聒噪 | skill_status_50 | status |
| 179 | 激怒 | skill_status_51 | status |
| 180 | 伺机而动 | skill_status_52 | status |
| 181 | 加固 | skill_status_53 | status |
| 182 | 力量增效 | skill_status_54 | status |
| 183 | 休息回复 | skill_status_55 | status |
| 184 | 三连破 | skill_status_56 | status |
| 185 | 快速移动 | skill_status_57 | status |
| 186 | 退化 | skill_status_58 | status |
| 187 | 应激反应 | skill_status_59 | status |
| 188 | 咆哮 | skill_status_60 | status |
| 189 | 借用 | skill_status_61 | status |
| 190 | 无畏之心 | skill_defense_17 | defense |
| 191 | 血气 | skill_defense_18 | defense |
| 192 | 嗜痛 | skill_defense_19 | defense |
| 193 | 防反 | skill_defense_20 | defense |
| 194 | 防御 | skill_defense_21 | defense |
| 195 | 吓退 | skill_defense_22 | defense |
| 196 | 有效预防 | skill_defense_23 | defense |
| 197 | 魔能爆 | skill_c_119 | magical |
| 198 | 许愿星 | skill_20 | magical |
| 199 | 消毒法 | skill_c_120 | magical |
| 200 | 蓄能轰击 | skill_c_121 | magical |

## 精灵与特性

| ID | 精灵 | 特性 |
| --- | --- | --- |
| 1 | 迪莫 | 最好的伙伴 |
| 2 | 圣光迪莫（首领形态） | 裁决 |
| 3 | 圣草迪莫（首领形态） | 滋养 |
| 4 | 圣火迪莫（首领形态） | 点燃 |
| 5 | 圣水迪莫（首领形态） | 净化 |
| 6 | 喵喵 | 氧循环 |
| 7 | 喵呜 | 氧循环 |
| 8 | 魔力猫 | 氧循环 |
| 9 | 叶冕魔力猫（首领形态） | 深层氧循环 |
| 10 | 武斗酷猫（首领形态） | 草木苏醒时 |
| 11 | 火花 | 助燃 |
| 12 | 焰火 | 助燃 |
| 13 | 火神 | 助燃 |
| 14 | 烈火战神（首领形态） | 爆燃 |
| 15 | 水蓝蓝 | 浸润 |
| 16 | 波波拉 | 浸润 |
| 17 | 水灵 | 浸润 |
| 18 | 圣水守护（首领形态） | 浪潮 |
| 19 | 鸭吉吉（蓬松的样子） | 挺起胸脯 |
| 20 | 鸭吉吉（紧实的样子） | 挺起胸脯 |
| 21 | 鸭吉吉（急急急鸭） | 挺起胸脯 |
| 22 | 鸭吉吉（等一等鸭） | 挺起胸脯 |
| 23 | 鸭吉吉（燃了鸭） | 挺起胸脯 |
| 24 | 鸭吉吉（起来鸭） | 挺起胸脯 |
| 25 | 鸭吉吉国王（蓬松的样子） | “国王”的威严 |
| 26 | 鸭吉吉国王（紧实的样子） | “国王”的威严 |
| 27 | 鸭吉吉国王（急急急鸭） | “国王”的威严 |
| 28 | 鸭吉吉国王（等一等鸭） | “国王”的威严 |
| 29 | 鸭吉吉国王（燃了鸭） | “国王”的威严 |
| 30 | 鸭吉吉国王（起来鸭） | “国王”的威严 |
| 31 | 板板壳 | 缩壳 |
| 32 | 板板壳（蜕皮时的样子） | 缩壳 |
| 33 | 咔咔壳 | 缩壳 |
| 34 | 咔咔壳（蜕皮时的样子） | 缩壳 |
| 35 | 水泡壳 | 缩壳 |
| 36 | 水泡壳（蜕皮时的样子） | 缩壳 |
| 37 | 锥尾羊 | 碰瓷 |
| 38 | 铃兰羊 | 碰瓷 |
| 39 | 花影羚羊 | 碰瓷 |
| 40 | 雪绒鸟（春天的样子） | 顺风 |
| 41 | 雪绒鸟（夏天的样子） | 顺风 |
| 42 | 雪绒鸟（秋天的样子） | 顺风 |
| 43 | 雪绒鸟 | 顺风 |
| 44 | 冬羽雀 | 顺风 |
| 45 | 冬羽雀（春天的样子） | 顺风 |
| 46 | 冬羽雀（夏天的样子） | 顺风 |
| 47 | 冬羽雀（秋天的样子） | 顺风 |
| 48 | 岚鸟 | 顺风 |
| 49 | 岚鸟（春天的样子） | 顺风 |
| 50 | 岚鸟（夏天的样子） | 顺风 |
| 51 | 岚鸟（秋天的样子） | 顺风 |
| 52 | 霜翼领主 | 破空 |
| 53 | 霜翼领主（春天的样子） | 破空 |
| 54 | 霜翼领主（夏天的样子） | 破空 |
| 55 | 霜翼领主（秋天的样子） | 破空 |
| 56 | 小灵菇 | 毒蘑菇 |
| 57 | 幻灵菇 | 毒蘑菇 |
| 58 | 幻影灵菇 | 毒蘑菇 |
| 59 | 石肤蜥 | 刺肤 |
| 60 | 石肤蜥（球球尾巴的样子） | 刺肤 |
| 61 | 石刺蜥 | 刺肤 |
| 62 | 石刺蜥（球球尾巴的样子） | 刺肤 |
| 63 | 石冠王蜥 | 刺肤 |
| 64 | 石冠王蜥（球球尾巴的样子） | 刺肤 |
| 65 | 布是石 | 地脉 |
| 66 | 布是岩 | 地脉 |
| 67 | 布克棱岩 | 地脉 |
| 68 | 迷嶂布莱克（首领形态） | 地脉馈赠 |
| 69 | 恶魔叮 | 渴求 |
| 70 | 叮叮恶魔 | 渴求 |
| 71 | 恶魔男爵（首领形态） | 贪得无厌 |
| 72 | 毛毛 | 化茧 |
| 73 | 爬爬 | 化茧 |
| 74 | 化蝶（平常的样子） | 化茧 |
| 75 | 化蝶（幽冥眼的样子） | 化茧 |
| 76 | 化蝶（喵喵的样子） | 化茧 |
| 77 | 化蝶（奇丽花的样子） | 化茧 |
| 78 | 幽影树 | 小偷小摸 |
| 79 | 幻影荆棘（首领形态） | 大捞一笔 |
| 80 | 小鼠獭 | 保守派 |
| 81 | 燕尾獭 | 保守派 |
| 82 | 卷胡巨獭 | 保守派 |
| 83 | 矿晶虫 | 偏振 |
| 84 | 晶石蜗（西瓜碧玺的样子） | 偏振 |
| 85 | 晶石蜗（莲花刚玉的样子） | 偏振 |
| 86 | 晶石蜗（星彩榴石的样子） | 偏振 |
| 87 | 晶石蜗（火山琉璃的样子） | 偏振 |
| 88 | 晶石蜗（蓝锥矿的样子） | 偏振 |
| 89 | 晶石蜗（烧蓝黄金的样子） | 偏振 |
| 90 | 钻石蜗（西瓜碧玺的样子） | 完全偏振 |
| 91 | 钻石蜗（莲花刚玉的样子） | 完全偏振 |
| 92 | 钻石蜗（星彩榴石的样子） | 完全偏振 |
| 93 | 钻石蜗（火山琉璃的样子） | 完全偏振 |
| 94 | 钻石蜗（蓝锥矿的样子） | 完全偏振 |
| 95 | 钻石蜗（烧蓝黄金的样子） | 完全偏振 |
| 96 | 奇丽草 | 养分重吸收 |
| 97 | 奇丽叶 | 养分重吸收 |
| 98 | 奇丽花 | 养分重吸收 |
| 99 | 奇丽果（首领形态） | 养分内循环 |
| 100 | 丢丢（草地附近的样子） | 诈死 |
| 101 | 丢丢（火山附近的样子） | 诈死 |
| 102 | 丢丢（沙地附近的样子） | 诈死 |
| 103 | 丢丢（雪山附近的样子） | 诈死 |
| 104 | 卡卡虫（草地附近的样子） | 诈死 |
| 105 | 卡卡虫（火山附近的样子） | 诈死 |
| 106 | 卡卡虫（沙地附近的样子） | 诈死 |
| 107 | 卡卡虫（雪山附近的样子） | 诈死 |
| 108 | 卡瓦重（草地附近的样子） | 诈死 |
| 109 | 卡瓦重（火山附近的样子） | 诈死 |
| 110 | 卡瓦重（沙地附近的样子） | 诈死 |
| 111 | 卡瓦重（雪山附近的样子） | 诈死 |
| 112 | 护主犬 | 专注力 |
| 113 | 音速犬 | 专注力 |
| 114 | 风暴战犬（首领形态） | 全神贯注 |
| 115 | 绿耳松鼠 | 囤积 |
| 116 | 抱枕松鼠 | 囤积 |
| 117 | 蹦床松鼠 | 囤积 |
| 118 | 嘟嘟煲 | 复方汤剂 |
| 119 | 嘟嘟锅 | 复方汤剂 |
| 120 | 小灵面 | 惊吓 |
| 121 | 暗影灵面（睁眼的样子） | 惊吓 |
| 122 | 暗影灵面（闭眼的样子） | 惊吓 |
| 123 | 幽冥眼（睁眼的样子） | 惊吓 |
| 124 | 幽冥眼（闭眼的样子） | 惊吓 |
| 125 | 梦游（穿旧睡衣的样子） | 做噩梦 |
| 126 | 梦游（穿星星睡衣的样子） | 做噩梦 |
| 127 | 梦悠悠（穿旧睡衣的样子） | 做噩梦 |
| 128 | 梦悠悠（穿星星睡衣的样子） | 做噩梦 |
| 129 | 兽花蕾 | 稀兽花宝 |
| 130 | 伏地兽 | 壮胆 |
| 131 | 贪食鼹 | 壮胆 |
| 132 | 巨噬针鼹 | 壮胆 |
| 133 | 蹦蹦种子（海神球形态） | 生物碱 |
| 134 | 蹦蹦种子（彩玉球形态） | 生物碱 |
| 135 | 蹦蹦种子（短毛球形态） | 生物碱 |
| 136 | 蹦蹦种子（象牙球形态） | 生物碱 |
| 137 | 蹦蹦草（海神球形态） | 生物碱 |
| 138 | 蹦蹦草（彩玉球形态） | 生物碱 |
| 139 | 蹦蹦草（短毛球形态） | 生物碱 |
| 140 | 蹦蹦草（象牙球形态） | 生物碱 |
| 141 | 蹦蹦花（海神球形态） | 生物碱 |
| 142 | 蹦蹦花（彩玉球形态） | 生物碱 |
| 143 | 蹦蹦花（短毛球形态） | 生物碱 |
| 144 | 蹦蹦花（象牙球形态） | 生物碱 |
| 145 | 蹦蹦果（海神球形态） | 高浓生物碱 |
| 146 | 蹦蹦果（彩玉球形态） | 高浓生物碱 |
| 147 | 蹦蹦果（短毛球形态） | 高浓生物碱 |
| 148 | 蹦蹦果（象牙球形态） | 高浓生物碱 |
| 149 | 电咩咩 | 快充 |
| 150 | 粉咩咩 | 快充 |
| 151 | 电球咩咩 | 快充 |
| 152 | 蒲公英 | 勇敢 |
| 153 | 蒲公英娃娃 | 勇敢 |
| 154 | 伊贝儿 | 腐植循环 |
| 155 | 伊贝粉粉 | 腐植循环 |
| 156 | 白发懒人 | 慢热型 |
| 157 | 动力猿 | 慢热型 |
| 158 | 瞌睡王 | 慢热型 |
| 159 | 海盔虫 | 溶解扩散 |
| 160 | 海盔虫（磨损的样子） | 溶解扩散 |
| 161 | 刺盔虫 | 溶解扩散 |
| 162 | 刺盔虫（磨损的样子） | 溶解扩散 |
| 163 | 千棘盔 | 溶解扩散 |
| 164 | 千棘盔（磨损的样子） | 溶解扩散 |
| 165 | 千棘海针 | 溶解腐蚀 |
| 166 | 千棘海针（磨损的样子） | 溶解腐蚀 |
| 167 | 菊花梨 | 无忧无虑 |
| 168 | 小星光（星光能量的样子） | 电流刺激 |
| 169 | 小星光（月光能量的样子） | 电流刺激 |
| 170 | 星光狮（星光能量的样子） | 电流刺激 |
| 171 | 星光狮（月光能量的样子） | 电流刺激 |
| 172 | 一窝蜂 | 虫群鼓舞 |
| 173 | 黄蜂后 | 虫群鼓舞 |
| 174 | 花魁蜂后 | 虫群鼓舞 |
| 175 | 女王蜂（首领形态） | 虫群突袭 |
| 176 | 小夜 | 嫁祸 |
| 177 | 紫夜 | 嫁祸 |
| 178 | 朔夜伊芙 | 嫁祸 |
| 179 | 乖乖鹄 | 洁癖 |
| 180 | 蓝珠天鹅 | 洁癖 |
| 181 | 翠顶夫人 | 洁癖 |
| 182 | 黑羽夫人 | 孤傲 |
| 183 | 锤头鹳 | 快锤 |
| 184 | 绿草精灵 | 木桶戏法 |
| 185 | 魔草巫灵 | 木桶戏法 |
| 186 | 记忆石 | 不移 |
| 187 | 咔咔羽毛 | 咔咔冲刺 |
| 188 | 咔咔雀 | 咔咔冲刺 |
| 189 | 咔咔鸟 | 咔咔冲刺 |
| 190 | 小草虫 | 花精灵 |
| 191 | 草衣虫 | 花精灵 |
| 192 | 花衣蝶 | 花精灵 |
| 193 | 绿翼鸟 | 自由飘 |
| 194 | 魔翼鸟 | 自由飘 |
| 195 | 魔眷鸟 | 自由飘 |
| 196 | 阿米亚特 | 石头大餐 |
| 197 | 阿米樱 | 石头大餐 |
| 198 | 罗隐 | 石头大餐 |
| 199 | 深渊罗隐（首领形态） | 盛宴 |
| 200 | 风铃鲨 | 水翼推进 |
