const assert = require('assert');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const bundle = require('./index.js');
const rules = require('./rule-index.json');

function verifyRange(values, id) {
  assert.strictEqual(values.length, 200);
  assert.deepStrictEqual(values.map(id).sort(function(a, b) { return a - b; }),
    Array.from({ length: 200 }, function(_, i) { return i + 1; }));
}

verifyRange(bundle.pets, function(pet) { return pet.id; });
verifyRange(bundle.skills, function(skill) { return skill.catalogId; });
assert.strictEqual(bundle.traits.length, 65);
bundle.pets.forEach(function(pet) {
  assert(bundle.traits.some(function(trait) { return trait.name === pet.trait.name; }), pet.name);
});
bundle.skills.forEach(function(skill) {
  assert.strictEqual(skill.catalog.name, skill.runtime.name);
  assert(skill.runtime.effects || skill.runtime.category === 'gather', skill.runtime.name);
});
bundle.manifest.excerpts.forEach(function(excerpt) {
  const code = fs.readFileSync(path.join(__dirname, excerpt.artifact), 'utf8');
  const digest = crypto.createHash('sha256').update(code.slice(0, -1)).digest('hex');
  assert.strictEqual(digest, excerpt.sha256, excerpt.artifact);
  assert(excerpt.startLine > 0 && excerpt.endLine >= excerpt.startLine);
});
const artifacts = new Set(bundle.manifest.excerpts.map(function(excerpt) { return excerpt.artifact; }));
rules.skills.concat(rules.traits).forEach(function(rule) {
  assert(rule.excerpts.length || rule.disabled, rule.name + ' has no source route');
  rule.excerpts.forEach(function(file) { assert(artifacts.has(file), file); });
});
process.stdout.write('Public bundle: numbered scope, trait bindings, runtime definitions and source hashes PASS\n');
