# 战斗引擎规则公开包：精灵1–200、技能1–200

这是用于公开审阅的规则与实际源码摘录包，不是可独立运行的战斗引擎。
原引擎继续使用原有文件；本目录可以独立复制到另一个Git仓库。

## 编号口径

- 精灵：`utils/pets_data.js` 的数字 `id` 1–200，包含这一区间内的首领形态。
- 技能：`utils/skills_data.js` 的数字 `id` 1–200，按名称关联当前运行时规则。
- 内部编号不能当成图鉴编号。例如图鉴1号「闪光冲击」对应 `skill_59`，图鉴6号「放晴」对应 `skill_status_1`。
- 特性：上述200只精灵实际绑定的65种特性，按名称去重。同一特性可能被区间外精灵共用；本包不附带区间外精灵的绑定。

## 文件内容

| 文件 | 内容 |
| --- | --- |
| `data/pets.json` | 200只精灵的编号、名称、系别、特性及文字 |
| `data/traits.json` | 65种特性的触发、条件、效果和持续性配置 |
| `data/skills.json` | 200个技能的图鉴信息、内部编号、当前运行时定义 |
| `source/` | 从引擎直接摘出的效果分支、条件分支、应对/折射分支及相关辅助函数 |
| `manifest.json` | 每份摘录的原文件、行号、源码哈希与效果类型 |
| `dependencies.json` | 尚需原引擎提供的调用，以及相关内部状态字段在引擎中的引用位置 |
| `index.js` | 加载公开规则数据的CommonJS入口 |
| `CATALOG.md` | 技能编号对照表和精灵特性清单 |
| `rule-index.json` | 按每个技能/特性查阅对应执行源码摘录 |

`.js.txt` 文件保留原始源码文本。它可能是一个 `case` 分支或闭包中的辅助函数，
需要在 `manifest.json` 标明的原函数上下文中阅读，不能直接 `require()` 执行。
连续的贯穿式 `case` 标签作为一组保留，因此可能包含同一共享分支的其他标签。
公共辅助代码也可能引用其他规则：这表示依赖关系，不意味着公开了那些规则的数据集。

图鉴文本与运行时定义同时保留。两者如有差异，本包如实展示现状，不将本次导出作为规则修复或一致性认证。
「木桶戏法」按项目现有规则暂不实现，保留 `skip` 和原因，阅读索引标记为停用，不能将空效果解释成已生效。

## 阅读生效链路

1. 在 `data/skills.json` 用 `catalogId` 找技能，查看 `runtime.effects`、`conditional`、`on_counter` 与嵌套效果。
2. 在 `manifest.json` 用效果的 `type` 查 `labels`；`name` 是原函数名。
3. 技能执行主要在 `SkillExecutor` 的 `_executeEffect`；应对由 `_applyCounterEffects` 处理；条件由 `_applyConditionalEffects` 处理。
4. 特性执行主要在 `TraitSystem` 的 `_applyEffect`；触发条件由 `_checkCondition` 处理。
5. 效果设置的 `_` 字段可能由后续回合、换宠或伤害管线消费，需继续查 `dependencies.json`。

仅复制规则定义不能复现结算；这些摘录也不包含整个调度器、完整初始状态、完整状态/印记系统或技能随机池。
`dependencies.json` 中未复制的调用保留原位置供核对，不提供虚假的替代实现。

## 公共依赖

- `BattleEngine`：回合顺序、行动、应对时机、击败、换宠和回合末结算。
- `DamageCalculator`、`TypeAdvantage`：伤害公式、系别倍率。
- `StatusSystem` 与状态定义：状态/印记新增、免疫、叠层、消耗与持续效果。
- `PetSystem`：能力值、初始能量和特性绑定。
- `PowerModifier`、`BurstManager`、`DedicationManager`：威力、迸发、奉献修正。
- `WeatherSystem`、`BattleConstants`：天气与公共常量。
- `deps`、`skillsData`、`traitSystem`、`statusSystem`、`state`、`random` 等闭包变量：原引擎注入。

本包未包含云函数、API服务、API密钥、云环境配置、小程序页面、图片、AI模型或训练数据。
公开许可尚未指定；如需允许第三方修改和再分发，应由仓库所有者选择许可证并补充 `LICENSE`。

## 验证与更新

在本目录运行 `node verify.js`（或 `npm test`），检查编号、绑定、定义以及源码摘录哈希。
这不是战斗正确性的全量回归测试。

在原项目中运行：

```sh
node tools/export-public-battle-rules.js
node tools/export-public-battle-rules.js --check
node publication/battle-rules-1-200/verify.js
```

导出依赖原项目已安装的TypeScript，仅用作源码语法树分析；公开包自身的验证只需Node.js内置库。
更新后应核对Git差异；如发现不在本次导出清单中的文件，导出器会报错并停止，
须先检查过期文件或手工补充内容，再更新，避免旧源码混入新的公开包。
